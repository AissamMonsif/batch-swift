package com.eai.batchswift;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.springframework.batch.item.database.ItemPreparedStatementSetter;

import com.eai.batchswift.entities.Swift;

public class SwiftItemPreparedStatementSetter implements ItemPreparedStatementSetter<Swift> {

	@Override
	public void setValues(Swift item, PreparedStatement ps) throws SQLException {
		//ps.setInt(1, item.getIdSwift());
		//ps.setString(3, item.getMessageSwift());
		if(item.getMessageSwift().contains("{2:I")) {
			ps.setString(4, "Entrant");
		}else if(item.getMessageSwift().contains("{2:O")) {
			ps.setString(4, "Sortant");
		}
	}

}
