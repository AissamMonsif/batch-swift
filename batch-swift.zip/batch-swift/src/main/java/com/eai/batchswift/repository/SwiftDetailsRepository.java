package com.eai.batchswift.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.eai.batchswift.entities.SwiftDetails;

public interface SwiftDetailsRepository extends JpaRepository<SwiftDetails,Integer> {

}
