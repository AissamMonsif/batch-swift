package com.eai.batchswift.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Swift2 {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	@Column(name = "field_1")
	private String field1;
	
	@Column(name = "field_2")
	private String field2;
	
	@Column(name = "sens")
	private String sens;
	
	@Column(name = "type_sw")
	private String typeSw;

	@Column(name = "id_tsw")
	private int idTsw;

	public Swift2(String field1, String field2, String sens, String typeSw, int idTsw) {
		super();
		this.field1 = field1;
		this.field2 = field2;
		this.sens = sens;
		this.typeSw = typeSw;
		this.idTsw = idTsw;
	}

	public Swift2() {
		super();
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getField1() {
		return field1;
	}

	public void setField1(String field1) {
		this.field1 = field1;
	}

	public String getField2() {
		return field2;
	}

	public void setField2(String field2) {
		this.field2 = field2;
	}

	public String getSens() {
		return sens;
	}

	public void setSens(String sens) {
		this.sens = sens;
	}

	public String getTypeSw() {
		return typeSw;
	}

	public void setTypeSw(String typeSw) {
		this.typeSw = typeSw;
	}

	public int getIdTsw() {
		return idTsw;
	}

	public void setIdTsw(int idTsw) {
		this.idTsw = idTsw;
	}

	@Override
	public String toString() {
		return "Swift2 [id=" + id + ", field1=" + field1 + ", field2=" + field2 + ", sens=" + sens + ", typeSw="
				+ typeSw + "]";
	}

}
