package com.eai.batchswift.entities;

import java.util.Date;
import java.util.List;
import com.eai.batchswift.entities.*;
import com.zaxxer.hikari.util.SuspendResumeLock;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import org.apache.commons.lang3.StringUtils;

@Entity
public class Swift {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id_swift")
	private int idSwift;

	@Column(name = "date_insertion")
	private Date dateInsertion;

	@Column(name = "sens")
	private String sens;

	@ManyToOne
	@JoinColumn(name = "id_type_swift")
	private TypeSwift typeSwift;

	@OneToMany(mappedBy = "swift")
	private List<SwiftDetails> listeSwiftDetails;
	
	@Column(name="message_swift")
	private String messageSwift;

	public Swift(int idSwift, Date dateInsertion, String sens, TypeSwift typeSwift, String messageSwift) {
		super();
		this.idSwift = idSwift;
		this.dateInsertion = dateInsertion;
		this.sens = sens;
		this.typeSwift = typeSwift;
		this.messageSwift = messageSwift;
	}

	public String getMessageSwift() {
		return messageSwift;
	}

	public void setMessageSwift(String messageSwift) {
		this.messageSwift = messageSwift;
	}

	public Swift() {
		super();
	}

	public List<SwiftDetails> getListeSwiftDetails() {
		return listeSwiftDetails;
	}

	public void setListeSwiftDetails(List<SwiftDetails> listeSwiftDetails) {
		this.listeSwiftDetails = listeSwiftDetails;
	}

	public int getIdSwift() {
		return idSwift;
	}

	public void setIdSwift(int idSwift) {
		this.idSwift = idSwift;
	}

	public Date getDateInsertion() {
		return dateInsertion;
	}

	public void setDateInsertion(Date dateInsertion) {
		this.dateInsertion = dateInsertion;
	}

	public TypeSwift getTypeSwift() {
		return typeSwift;
	}

	public void setTypeSwift(TypeSwift typeSwift) {
		this.typeSwift = typeSwift;
	}

	public String getSens() {
		return sens;
	}

	public void setSens(String sens) {
		this.sens = sens;
	}

	@Override
	public String toString() {
		return "Swift [idSwift=" + idSwift + ", dateInsertion=" + dateInsertion + ", sens=" + sens + ", typeSwift="
				+ typeSwift + ", listeSwiftDetails=" + listeSwiftDetails + ", messageSwift=" + messageSwift + "]";
	}
	public String getBlock1() {

		return "{1: " + StringUtils.substringBetween(messageSwift, "{1:", "}{2")+"}";
	}

	public String getBlock2() {

		return "{2: " + StringUtils.substringBetween(messageSwift, "{2:I", "}{3")+"}";
	}

	public String getBlock3() {

		return "{3: " + StringUtils.substringBetween(messageSwift, "{3:", "}{4")+"}";
	}

	public String getBlock4() {

		return "{4: " + StringUtils.substringBetween(messageSwift, "{4:", "}{5")+"}";
	}

	public String getBlock5() {

		return "{5: " + StringUtils.substringBetween(messageSwift, "{5:", "}}")+"}}";
	}
	
	



}
