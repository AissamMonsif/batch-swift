package com.eai.batchswift;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;

import org.hibernate.SessionFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.eai.batchswift.entities.Swift;
import com.eai.batchswift.entities.SwiftDetails;
import com.eai.batchswift.entities.TypeChamp;

@SpringBootApplication
public class BatchSwiftApplication {

	public static void main(String[] args) {
		SpringApplication.run(BatchSwiftApplication.class, args);
		/*Swift swift  = new Swift();
		swift.setSens("I");
		List<SwiftDetails> swiftDetails = new ArrayList<SwiftDetails>();
		SwiftDetails SwiftDetail = new SwiftDetails();
		TypeChamp typeChamp = new TypeChamp();
		typeChamp.setIdTypeChamp(20);
		SwiftDetail.setValue("valeur champs 20");
		SwiftDetail.setTypeChamp(typeChamp);
		swift.setListeSwiftDetails(swiftDetails);*/
		
	}

}
