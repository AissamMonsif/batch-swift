package com.eai.batchswift;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.springframework.batch.item.database.ItemPreparedStatementSetter;

import com.eai.batchswift.entities.TypeSwift;

public class TypeSwiftItemPreparedStatementSetter implements ItemPreparedStatementSetter<TypeSwift> {


	@Override
	public void setValues(final TypeSwift ts, final PreparedStatement ps) throws SQLException {
		
		ps.setInt(1, ts.getIdTypeSwift());
		ps.setString(2, ts.getCategorie());
		ps.setString(3, ts.getDesignation());
		ps.setString(4, ts.getLibelle());

	}

}
