package com.eai.batchswift.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.eai.batchswift.entities.SwiftDetails;
import com.eai.batchswift.repository.SwiftDetailsRepository;

public class SwiftDetailsService {

	@Autowired
	private SwiftDetailsRepository swiftDetailsRepository;

	public List<SwiftDetails> listAll() {
		return swiftDetailsRepository.findAll();
	}

	public SwiftDetails get(int id) {
		return swiftDetailsRepository.findById(id).get();
	}
}
