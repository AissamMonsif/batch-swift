package com.eai.batchswift;

import java.util.List;

import org.springframework.batch.item.ItemWriter;

public class ConsoleItemWriter<T> implements ItemWriter<T> {

	@Override
	public void write(List<? extends T> items) throws Exception {
		// TODO Auto-generated method stub
		for(T item:items) {
			System.out.println(item.toString());
		}
	}

}
