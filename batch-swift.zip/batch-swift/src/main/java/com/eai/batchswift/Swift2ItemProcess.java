package com.eai.batchswift;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;

import com.eai.batchswift.entities.Swift;
import com.eai.batchswift.entities.Swift2;
import com.eai.batchswift.entities.SwiftDetails;
import com.eai.batchswift.entities.TypeChamp;
import com.eai.batchswift.entities.TypeSwift;
import com.eai.batchswift.repository.SwiftRepository;
import com.eai.batchswift.repository.TypeChampRepository;
import com.eai.batchswift.repository.TypeSwiftRepository;
import com.eai.batchswift.services.TypeChampService;
import com.eai.batchswift.services.TypeSwiftService;

public class Swift2ItemProcess implements ItemProcessor<Swift2, Swift2> {

	String msg = "";
	String sens = "";
	
	private int idts;
	TypeChamp tc= new TypeChamp();
	
	@Autowired
	private TypeSwiftRepository typeSwiftRepo;
	
	@Autowired
	private SwiftRepository swiftRepo;
	
	@Autowired
	private TypeChampRepository typeChampRepo;
	
	@Override
	public Swift2 process(Swift2 item) throws Exception {

		if (item.getField2().equals("")) {
		
			msg += item.getField1();

			return null;
		
		} else {
			
			msg += item.getField1();
			
			if (msg.contains("{2:I")) {
			
				item.setSens("Entrant");
			
			} else if (msg.contains("{2:O")) {
			
				item.setSens("Sortant");
			
			}

			item.setField1(msg);

			String s = org.apache.commons.lang3.StringUtils
					.substringBetween(item.getField1(), "}{2:", "}{");
			
			item.setTypeSw("MT" + s.subSequence(1, 4));
						
			List<TypeSwift> listTypeSwifts = typeSwiftRepo.findAll();
			
			for(TypeSwift t : listTypeSwifts) {
			
				t.getLibelle();
				
				if(t.getLibelle().equals(item.getTypeSw())==true) {
				
					item.setIdTsw(t.getIdTypeSwift());
				}
			}
			
			List<Swift> swifts = swiftRepo.findAll();
			
			
			for(Swift swift :swifts) {
				
				//tc.setIdTypeChamp(swift.getTypeSwift().getIdTypeSwift());
				//typeChampRepo.save(tc);
			}
		
			
			
			msg = item.getField2();
			
			return item;
		}
	}

}
