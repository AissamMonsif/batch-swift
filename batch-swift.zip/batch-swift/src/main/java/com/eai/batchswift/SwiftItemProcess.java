package com.eai.batchswift;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemProcessor;

import com.eai.batchswift.entities.Swift;
import com.eai.batchswift.entities.Swift2;
import com.eai.batchswift.entities.SwiftDetails;
import com.eai.batchswift.entities.TypeSwift;

public class SwiftItemProcess implements ItemProcessor<Swift, Swift> {

	String msg = "";
	TypeSwift ts = new TypeSwift();

	@Override
	public Swift process(Swift swift) throws Exception {
		Swift2 sw2 = new Swift2();
		if (sw2.getField2().equals("")) {
			msg += sw2.getField1();
			// item.setField1(msg);
			return null;
		} else {
			msg += sw2.getField1();
			sw2.setField1(msg);
			swift.setMessageSwift(msg);
			msg = sw2.getField2();
			return swift;
		}
	}
}
