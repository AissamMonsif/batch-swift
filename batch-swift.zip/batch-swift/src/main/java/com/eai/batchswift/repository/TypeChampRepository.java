package com.eai.batchswift.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.eai.batchswift.entities.TypeChamp;

public interface TypeChampRepository extends JpaRepository<TypeChamp, Integer>{

}
