package com.eai.batchswift.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.eai.batchswift.entities.Swift;

public interface SwiftRepository extends JpaRepository<Swift, Integer> {

}
