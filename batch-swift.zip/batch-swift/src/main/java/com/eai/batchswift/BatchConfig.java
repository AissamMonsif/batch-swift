package com.eai.batchswift;

import javax.sql.DataSource;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.job.builder.FlowBuilder;
import org.springframework.batch.core.job.flow.Flow;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.item.database.BeanPropertyItemSqlParameterSourceProvider;
import org.springframework.batch.item.database.ItemPreparedStatementSetter;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.database.builder.JdbcBatchItemWriterBuilder;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.MultiResourceItemReader;
import org.springframework.batch.item.file.builder.FlatFileItemReaderBuilder;
import org.springframework.batch.item.file.builder.FlatFileItemReaderBuilder.DelimitedBuilder;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;

import com.eai.batchswift.entities.Swift;
import com.eai.batchswift.entities.Swift2;
import com.eai.batchswift.entities.TypeSwift;

@Configuration
@EnableBatchProcessing
public class BatchConfig {

	@Autowired
	private JobBuilderFactory jobBuilderFactory;

	@Autowired
	private StepBuilderFactory stepBuilderFactory;

	@Value("input/swift*.txt")
	private Resource[] inputResources;

	@Bean
	public Job readSwiftsFilesJob() {
		return jobBuilderFactory.get("readSwiftsFilesJob").incrementer(new RunIdIncrementer())
				//.start(chargementTypeSwiftsStep(null))
				.start(chargementSwifts()).next(stepSwiftWriterDataBase(null))
				.build();
	}

	@Bean
	public Step chargementSwifts() {
		return stepBuilderFactory.get("chargementSwifts").<Swift2, Swift2>chunk(3).reader(multiResourceItemReader())
				.writer(writerConsole()).build();
	}
	
	//ce bout de code est utilisé pour remplir la table type_swift
/*
	@Bean
	public Step chargementTypeSwiftsStep(final StepBuilderFactory builderFactory) {
		return builderFactory.get("chargementTypeSwiftsStep").<TypeSwift, TypeSwift>chunk(20)
				.reader(typeSwiftItemReader(null)).writer(typeSwiftItemWriter(null)).build();
	}

	@Bean
	public JdbcBatchItemWriter<TypeSwift> typeSwiftItemWriter(final DataSource dataSource) {
		return new JdbcBatchItemWriterBuilder<TypeSwift>().dataSource(dataSource).sql("insert into type_swift(id_type_swift,categorie,designation,libelle) VALUES (?,?,?,?);")
				.itemPreparedStatementSetter(new TypeSwiftItemPreparedStatementSetter()).build();
	}

	@Bean
	@StepScope
	public FlatFileItemReader<TypeSwift> typeSwiftItemReader(
			@Value("#{jobParameters['typeSwift']}") final Resource inputFile) {
		return new FlatFileItemReaderBuilder<TypeSwift>().name("typeSwiftItemReader").resource(inputFile).delimited()
				.delimiter(";").names(new String[] {"id_type_swift", "libelle", "designation", "categorie" })
				.targetType(TypeSwift.class).build();
	}
*/
	@Bean
	public ConsoleItemWriter<Swift2> writerConsole() {
		return new ConsoleItemWriter<Swift2>();
	}

	@Bean
	public Step stepSwiftWriterDataBase(JdbcBatchItemWriter<Swift2> writerDataBase) {
		return stepBuilderFactory.get("stepSwiftWriterDataBase").<Swift2, Swift2>chunk(3)
				.reader(multiResourceItemReader()).processor(processorSwift2()).writer(writerDataBase).build();
	}

	@Bean
	public Swift2ItemProcess processorSwift2() {
		return new Swift2ItemProcess();
	}

	@Bean
	public JdbcBatchItemWriter<Swift2> writerSwift(DataSource dataSource) {
		return new JdbcBatchItemWriterBuilder<Swift2>()
				.itemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider<>())
				.sql("INSERT INTO swift (date_insertion,message_swift,sens,id_type_swift) "
				+ "VALUES (NOW(),:field1,:sens,:idTsw)")
				//.itemPreparedStatementSetter(new SwiftItemPreparedStatementSetter())
				.dataSource(dataSource).build();
	}
	
	@Bean
	public MultiResourceItemReader<Swift2> multiResourceItemReader() {
		MultiResourceItemReader<Swift2> resourceItemReader = new MultiResourceItemReader<Swift2>();
		resourceItemReader.setResources(inputResources);
		resourceItemReader.setDelegate(reader());
		return resourceItemReader;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Bean
	public FlatFileItemReader<Swift2> reader() {

		DelimitedLineTokenizer tokenizer = new DelimitedLineTokenizer();
		tokenizer.setDelimiter("$");
		
		tokenizer.setNames(new String[] { "field1","field2" });
		tokenizer.setStrict(false);
		
		DefaultLineMapper lineMapper = new DefaultLineMapper<Swift2>();
		lineMapper.setLineTokenizer(tokenizer);

		return new FlatFileItemReaderBuilder<Swift2>().name("swiftItemReader")
				
				.lineTokenizer(tokenizer)
				.fieldSetMapper(new BeanWrapperFieldSetMapper<Swift2>() {
					{
						setTargetType(Swift2.class);
					}
				}).build();
	}

}
