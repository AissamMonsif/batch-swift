package com.eai.batchswift.entities;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
//@Table(name = "swift_details")
public class SwiftDetails {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id_swift_details")
	private int idSwiftDetails;

	@ManyToOne
	@JoinColumn(name = "id_swift")
	private Swift swift;

	@ManyToOne
	@JoinColumn(name = "id_type_champ")
	private TypeChamp typeChamp;

	@Column(name = "value")
	private String value;

	public int getIdSwiftDetails() {
		return idSwiftDetails;
	}

	public void setIdSwiftDetails(int idSwiftDetails) {
		this.idSwiftDetails = idSwiftDetails;
	}

	public Swift getSwift() {
		return swift;
	}

	public void setSwift(Swift swift) {
		this.swift = swift;
	}

	public TypeChamp getTypeChamp() {
		return typeChamp;
	}

	public void setTypeChamp(TypeChamp typeChamp) {
		this.typeChamp = typeChamp;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

}
