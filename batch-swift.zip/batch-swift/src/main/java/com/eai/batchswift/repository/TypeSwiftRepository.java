package com.eai.batchswift.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.eai.batchswift.entities.TypeSwift;

public interface TypeSwiftRepository extends JpaRepository<TypeSwift, Integer> {

}
