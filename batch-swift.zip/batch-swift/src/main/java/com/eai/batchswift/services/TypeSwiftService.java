package com.eai.batchswift.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.eai.batchswift.entities.TypeSwift;
import com.eai.batchswift.repository.TypeSwiftRepository;

public class TypeSwiftService {
	
	@Autowired
	private TypeSwiftRepository typeSwiftRepo;

	public List<TypeSwift> listAll() {
		return typeSwiftRepo.findAll();
	}

	public TypeSwift get(int id) {
		return typeSwiftRepo.findById(id).get();
	}
}
