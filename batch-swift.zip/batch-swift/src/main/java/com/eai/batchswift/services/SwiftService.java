package com.eai.batchswift.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.eai.batchswift.entities.Swift;
import com.eai.batchswift.repository.SwiftRepository;

public class SwiftService {

	@Autowired
	private SwiftRepository swiftRepo;

	public List<Swift> listAll() {
		return swiftRepo.findAll();
	}

	public Swift get(int id) {
		return swiftRepo.findById(id).get();
	}
}
