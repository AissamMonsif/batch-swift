package com.eai.batchswift.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.eai.batchswift.entities.TypeChamp;
import com.eai.batchswift.entities.TypeSwift;
import com.eai.batchswift.repository.TypeChampRepository;

public class TypeChampService {
	
	@Autowired
	private TypeChampRepository typeChampRepo;
	public List<TypeChamp> listAll() {
		return typeChampRepo.findAll();
	}

	public TypeChamp get(int id) {
		return typeChampRepo.findById(id).get();
	}
	
	 public void save(TypeChamp typeChamp) {
	        typeChampRepo.save(typeChamp);
	    }
}
